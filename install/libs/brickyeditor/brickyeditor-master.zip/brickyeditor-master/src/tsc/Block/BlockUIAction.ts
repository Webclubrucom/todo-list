namespace BrickyEditor {
    export class BlockUIAction {
        constructor(public icon: string, public action?: () => void, public title?: string) {
        }
    }
}