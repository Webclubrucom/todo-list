namespace BrickyEditor {
    export class TemplateGroup {
        constructor(
            public name: string, 
            public templates: Template[]) {
        }
    }
}